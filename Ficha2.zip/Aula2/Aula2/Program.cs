﻿using System;
using System.Collections.Generic;

namespace Aula2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Exercicio 3.1
            //Console.WriteLine("insira uma frase");
            //string frase = Console.ReadLine();
            //Console.WriteLine(frase.ToUpper());
            //Console.WriteLine(frase.Substring(0,1));
            //Console.WriteLine(frase[0]);
            //Console.WriteLine(frase.Length);

            // Exercicio 3.2
            //string xpto = "Lorem Ipsum dolor sit amet sit";
            //int posicao = xpto.IndexOf("amet");
            //Console.WriteLine(posicao);

            //Console.WriteLine("Insira uma palavra:");
            //string palavraAdicionar = Console.ReadLine();
            //xpto = xpto.Insert(posicao, palavraAdicionar+" ");
            //Console.WriteLine(xpto);

            // Exercicio 3.3
            //string nomesAutores = "Salvador. Benedita,, Vicente; Teresa";

            //char[] separdores = new char[] { '.', ',', ';'};
            //string[] arrayNomes = nomesAutores.Split(separdores, StringSplitOptions.RemoveEmptyEntries);

            //Console.WriteLine(string.Join(' ', arrayNomes));

            // Exercicio 3.4
            //int[] arrayNumerosImpares = new int[] { 1, 3, 5, 7, 9 };
            //Array.Reverse(arrayNumerosImpares);
            //Console.WriteLine(arrayNumerosImpares[1]);

            // Exercicio 3.5
            Console.WriteLine("Insira o numero de alunos:");
            int numero = Convert.ToInt32(Console.ReadLine());

            List<int> idades = new List<int>();
            int[] idadesArray = new int[numero];      

            for (int i = 0; i < numero; i++)
            {
                Console.WriteLine("Insira a idade da pessoa:");
                int idadeDoALuno = Convert.ToInt32(Console.ReadLine());
                idades.Add(idadeDoALuno); // versão List
                idadesArray[i] = idadeDoALuno; // versão Array
            }

            // A)
            idades.Sort(); // ordenação crescente da lista
            Array.Sort(idadesArray); // ordenação crescente do array

            Console.WriteLine("A pessoa mais nova tem {0} anos.", idades[0]);
            Console.WriteLine("A pessoa mais nova tem {0} anos.", idadesArray[0]);

            // B)
            idades[numero - 1] = idades[numero - 1] - 20;
            Console.WriteLine("Nova idade da pessoa mais velha = " + idades[numero - 1]);

            // C)
            Console.Write("A minha turma tem {0} alunos", idades.Count); // Total de itens da Lista
            Console.Write("A minha turma tem {0} alunos", idadesArray.Length); // Total de itens do array

        }
    }
}
