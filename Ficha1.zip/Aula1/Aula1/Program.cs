﻿using System;

namespace Aula1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Exercicio 1.1
            // Console.WriteLine("Hello");
            // Console.WriteLine("António Ramos");

            // Exercicio 1.2
            // int n1 = 5;
            // int n2 = 6;
            // int soma = n1 + n2;
            // Console.WriteLine("A soma dos números {0} e {1} é igual a {2}", n1, n2, soma);

            // Exercicio 1.3
            //Console.WriteLine("Insira um número:");
            //string input = Console.ReadLine();
            //Console.WriteLine(input);

            // Extra (Converter para inteiros) - Metodo Parse
            // string numero = "6.99";
            // int numeroConvertido = int.Parse(numero);
            // Console.WriteLine(numeroConvertido);

            // Extra (Converter para inteiros) - Metodo TryParse
            // string numero2 = "6,66";
            // int resultadoConvertido = 0;
            // int.TryParse(numero2, out resultadoConvertido);
            // Console.WriteLine(resultadoConvertido);

            // Extra (Converter para inteiros) - Metodo Convert.ToInt32
            // string numero3 = "9";
            // int resultadoConvertido2 = 0;
            // Convert.ToInt32(numero3);
            // Console.WriteLine(resultadoConvertido2);
        }
    }
}
