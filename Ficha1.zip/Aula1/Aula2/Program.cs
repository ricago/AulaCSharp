﻿using System;

namespace Aula2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Exercicio 2.1
            //Console.WriteLine("Insira um número:");
            //int input1 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Insira um segundo número:");
            //int input2 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("1º numero = {0}; 2º numero = {1}", input2, input1);

            // Exercicio 2.2
            //Console.WriteLine("Insira um número:");
            //int input1 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Insira um segundo número:");
            //int input2 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Insira um terceiro número:");
            //int input3 = Convert.ToInt32(Console.ReadLine());

            //int resultado = input1 * input2 * input3;
            //Console.WriteLine("Resultado = " + resultado);
            //Console.WriteLine("Resultado é {0}", input1 * input2 * input3);

            // Exercicio 2.3
            //Console.WriteLine("Insira um número:");
            //int input1 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Insira um segundo número:");
            //int input2 = Convert.ToInt32(Console.ReadLine());

            //int multiplicacao = input1 * input2;
            //int adicao = input1 + input2;
            //int subtracao = input1 - input2;
            //int divisao = input1 / input2;
            //int modulo = input1 % input2;

            //Console.WriteLine("Multiplicação de {0} e {1} = {2}", input1, input2, multiplicacao);
            //Console.WriteLine("Adicao de {0} e {1} = {2}", input1, input2, adicao);
            //Console.WriteLine("Subtracao de {0} e {1} = {2}", input1, input2, subtracao);
            //Console.WriteLine("Divisao de {0} e {1} = {2}", input1, input2, divisao);
            //Console.WriteLine("Modulo de {0} e {1} = {2}", input1, input2, modulo);

            // Exercicio 2.4
            //Console.WriteLine("Insira um número:");
            //int n1 = Convert.ToInt32(Console.ReadLine());
            //double cubo = n1 * n1 * n1;
            //double cubo2 = Math.Pow(n1,3);
            //Console.WriteLine("Cubo = {0}", cubo);
            //Console.WriteLine("Cubo2 = {0}", cubo2);

            // Exercicio 2.5
            Console.WriteLine("Insira um número:");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira um 2 número:");
            int n2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira um 3 número:");
            int n3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira um 4 número:");
            int n4 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira um 5 número:");
            int n5 = Convert.ToInt32(Console.ReadLine());

            float aaa = (n1 + n2 + n3 + n4 + n5) / 5;

            Console.WriteLine("A média dos seus números é: {0}", aaa);

        }
    }
}
