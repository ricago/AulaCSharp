﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> notasTurma = new List<int>();
            bool entraCiclo = true;

            while (entraCiclo) {
                
                // Pede e guarda a nota dentro da lista
                Console.WriteLine("Insira a nota do seu aluno.");
                int inputNota = Convert.ToInt32(Console.ReadLine());
                notasTurma.Add(inputNota);

                // Sai ou não do Ciclo
                Console.WriteLine("Prima 0 para parar ou 1 para continuar");
                string variavel = Console.ReadLine();
                if (variavel == "0") entraCiclo = !entraCiclo;

                //Console.WriteLine("Prima 0 para parar ou 1 para continuar");
                //entraCiclo = Convert.ToBoolean(Convert.ToInt32(Console.ReadLine()));
            }

            Console.Clear();

            int somaNotas = 0;

            foreach (int nota in notasTurma)
            {
                Console.WriteLine($"------ NOTA {nota}-----------");
                // versão 1 (IF)
                //if (nota >= 46) Console.WriteLine("O Aluno Passou."); else Console.WriteLine("O Aluno Não Passou.");

                // versão 2 (if ternary)
                //string sePassou = nota >= 46 ? "O Aluno Passou." : "O Aluno Não Passou.";
                //Console.WriteLine(sePassou);

                // versão 3 (if ternary ++ optimizado)
                if (nota >= 0 && nota <= 100) {
                    somaNotas += nota;
                    Console.WriteLine(nota >= 46 ? "O Aluno Passou." : "O Aluno Não Passou.");
                }                    

                CalculaQualitativa(nota);
            }

            // Média usando o LINQ
            double notasMedia = notasTurma.Average();
            //Console.WriteLine("A média (usando LINQ) dos alunos é: {0}", notasMedia);


            // Média usando usando a soma e o count
            //Console.WriteLine("A média (soma ciclo) dos alunos é: {0}", somaNotas / notasTurma.Count);

            Console.WriteLine("A média da turma {0}", CalculaQualitativa(notasMedia));
        }

        public static void CalculaQualitativa(int nota)
        {
            if (nota < 0 || nota > 100)
            {
                Console.WriteLine("WTF????? 101??");
            }
            else if (nota <= 45)
            {
                Console.WriteLine("Não atingiu");
            }
            else if (nota <= 65)
            {
                Console.WriteLine("Atingiu com alguma dificuldade");
            }
            else if (nota <= 87)
            {
                Console.WriteLine("Atingiu com facilidade");
            }
            else
            {
                Console.WriteLine("Atingiu com muita facilidade");
            }
        }

        public static string CalculaQualitativa(double nota)
        {
            if (nota < 0 || nota > 100)
            {
                return "WTF????? 101??";
            }
            else if (nota <= 45)
            {
                return "Não atingiu";
            }
            else if (nota <= 65)
            {
                return "Atingiu com alguma dificuldade";
            }
            else if (nota <= 87)
            {
                return "Atingiu com facilidade";
            }
            else
            {
                return "Atingiu com muita facilidade";
            }
        }
    }
}
