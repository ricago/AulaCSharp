﻿using System;

namespace F1cha3
{
    class Program
    {       
        public static bool ShowMenu()
        {
            Console.WriteLine("------------ Menu ------------ ");
            Console.WriteLine("pff escolha uma das seguintes opções");
            Console.WriteLine("1) Adição");
            Console.WriteLine("2) Subtração");
            Console.WriteLine("3) Multiplicação");
            Console.WriteLine("4) Divisão");
            Console.WriteLine("0) Sair");

            string input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    Console.WriteLine("Entramos na Adição");
                    //FazContas(input);
                    return false;
                    break;
                case "2":
                    Console.WriteLine("Entramos na Subtração");
                    return false;
                    break;
                case "3":
                    Console.WriteLine("Entramos na Multiplicação");
                    return false;
                    break;
                case "4":
                    Console.WriteLine("Entramos na Divisão");
                    return false;
                    break;
                defaut:
                    return true;
                    break;
            }
            return true;
        }

        static void Main(string[] args)
        {    
            /*  Exercicio 1 - Calculadora (Não Optimizado)   */
            
            float input2 = 0;
            float input3 = 0;

            /* MENU */
            Console.WriteLine("------------ Menu ------------ ");
            Console.WriteLine("pff escolha uma das seguintes opções");
            Console.WriteLine("1) Adição");
            Console.WriteLine("2) Subtração");
            Console.WriteLine("3) Multiplicação");
            Console.WriteLine("4) Divisão");
            Console.WriteLine("0) Sair");

            // Lê a escolha do cliente
            string input = Console.ReadLine();
            
            try {
                // Definir o calculo a fazer
                switch (input)
                {
                    case "1":
                        Console.WriteLine("Entramos na Adição");

                        Console.WriteLine("Digite um número para efetuar a sua conta:");
                        input2 = float.Parse(Console.ReadLine());
                        Console.WriteLine("Digite um outro número:");
                        input3 = float.Parse(Console.ReadLine());

                        Console.WriteLine("A soma dos seus números é {0}", input2 + input3);

                        break;
                    case "2":
                        Console.WriteLine("Entramos na Subtração");

                        Console.WriteLine("Digite um número para efetuar a sua conta:");
                        input2 = float.Parse(Console.ReadLine());
                        Console.WriteLine("Digite um outro número:");
                        input3 = float.Parse(Console.ReadLine());

                        Console.WriteLine("A subtração dos seus números é {0}", input2 - input3);
                        break;
                    case "3":
                        Console.WriteLine("Entramos na Multiplicação");

                        Console.WriteLine("Digite um número para efetuar a sua conta:");
                        input2 = float.Parse(Console.ReadLine());
                        Console.WriteLine("Digite um outro número:");
                        input3 = float.Parse(Console.ReadLine());

                        Console.WriteLine("A multiplicação dos seus números é {0}", input2 * input3);
                        break;
                    case "4":
                        Console.WriteLine("Entramos na Divisão");

                        Console.WriteLine("Digite um número para efetuar a sua conta:");
                        input2 = float.Parse(Console.ReadLine());
                        Console.WriteLine("Digite um outro número:");
                        input3 = float.Parse(Console.ReadLine());

                        Console.WriteLine("A divisão dos seus números é {0}", input2 / input3);
                        //return false;
                        break;
                    default:
                        Console.WriteLine("Opção Inválida.");
                        break;
                }                
            }
            catch (Exception exc)
            {
                Console.WriteLine("Houve um erro inesperado. Insira por favor um valor.");
                Console.WriteLine(exc.InnerException);
            }
        }
    }
}
