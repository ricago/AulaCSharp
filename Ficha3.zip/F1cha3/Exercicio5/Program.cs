﻿using System;

namespace Exercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Por favor insira a data de nascimento (dia/mês/ano)");
            string dataNascimento = Console.ReadLine();
            // 1ª forma de fazer parse
            // DateTime dta = Convert.ToDateTime(dataNascimento);

            // 2ª forma de fazer parse
            DateTime dta = DateTime.Parse(dataNascimento);

            // Fazer print da data em String
            //Console.WriteLine(dta.ToString());   

            // Adicionar dias, horas e minutos através de métodos do datatype DateTime
            // dta = dta.AddHours(5).AddDays(1).AddMinutes(30);

            DateTime dataHoje = DateTime.Now;
            //Console.WriteLine("dataHoje={0}", dataHoje.Year);
            //Console.WriteLine("dataNascimento={0}", dta.Year);

            // Achar a idade da pessoa
            int idadePessoa = dataHoje.Year - dta.Year;

            // Corrigir se a pessoa já fez ou não anos
            if (dataHoje.Month < dta.Month)
            {
                idadePessoa--;
            }
            else if(dataHoje.Month == dta.Month && dataHoje.Day < dta.Day)
            {
                idadePessoa--;
            }

            Console.WriteLine("idade atual = " + idadePessoa);



            Console.WriteLine($"O utilizador com a data de nascimento " +
                $"{dta.Day}-{dta.Month}-{dta.Year}," +
                $" pertence ao grupo etário {CalculaGrupoEtario(idadePessoa)}");


        }

        public static string CalculaGrupoEtario(int idade)
        {
            if(idade <= 14)
            {
                return "Jovens";
            }
            else if(idade <= 64){
                return "Adultos";
            }
            else
            {
                return "Idosos";
            }
        }
    }
}
