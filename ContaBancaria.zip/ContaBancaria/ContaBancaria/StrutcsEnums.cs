﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContaBancaria
{
	internal class StrutcsEnums
	{
		public struct Morada
		{
			public string Endereco { get; set; }
			public string Endereco1 { get; set; }
		}

	}
}
